<?php 

namespace Src\Router\Models\Users;

use Src\Router\Models\Users\Methods\GET;
use Src\Router\Models\Users\Methods\POST;
use Src\Router\Base\BaseRouter;

class Users implements BaseRouter 
{
    use Methods\GET;
    use Methods\POST;

    private $Methods = [
        'GET'  => [
            'users'
        ],

    ];

    public function addRoutes()
    {
        foreach($this->Methods as $method) {
            foreach($method as $route) {
                $this->$route();
            }
        }
    }
}