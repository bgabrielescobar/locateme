<?php

namespace Src\Router\Base;

interface BaseRouter
{
    public function addRoutes();
}